import React from "react";
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { ShoppingCart } from "lucide-react";

const products = [
  { id: 1, name: "Bayam Segar", price: "Rp5.000", image: "/images/bayam.jpg" },
  { id: 2, name: "Tomat Merah", price: "Rp8.000", image: "/images/tomat.jpg" },
  { id: 3, name: "Wortel Organik", price: "Rp10.000", image: "/images/wortel.jpg" },
];

export default function VegetableStore() {
  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Toko Sayur Segar</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {products.map((product) => (
          <Card key={product.id} className="overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-40 object-cover"
            />
            <CardContent className="p-4">
              <h2 className="text-lg font-semibold">{product.name}</h2>
              <p className="text-green-700 font-bold">{product.price}</p>
              <Button className="mt-2 w-full flex items-center justify-center">
                <ShoppingCart className="mr-2" size={16} /> Tambah ke Keranjang
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
